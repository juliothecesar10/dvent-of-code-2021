package Escola;

public interface IConjuntoDeDisciplinas {

	public String[] FiltroPorTurno(String turno);

	
}
