package sef.module14.sample;
//Complete Code
public enum Seasons {
	SPRING, SUMMER, FALL, WINTER
}
