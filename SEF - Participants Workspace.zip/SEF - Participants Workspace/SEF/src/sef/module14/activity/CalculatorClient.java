package sef.module14.activity;
//Needs to be completed
class Calculator {

	//1- Create an add method which can add multiple integer values
	//Use variable arguments for this
	
	
}

public class CalculatorClient
{
	public static void main(String[] args) {
		Calculator c = new Calculator();
		
		//2 - Call add method with multiple values
		
	}
}