package sef.module19.sample;

public interface Worker {

	public void doWork();
	
}
