package sef.module19.sample;

public interface AdapterInterface {
	public void execute();
}
