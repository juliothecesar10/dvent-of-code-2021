package sef.module5.sample;

public interface AdapterInterface {
	public void execute();
}
