/*
 * Created on Jun 25, 2008
 *
 * Hello World Program
 */

package sef.module3.sample;
import java.lang.*;
import java.util.Date;


/**
* @author John Doe
*/
public class MainSample {

	public static void main(String[] args) {
		//	This line prints out the String 'Hello World!' in the console
		System.out.println( "Welcome to Java!");
		Date theDateToday = new Date();
		
	}
}