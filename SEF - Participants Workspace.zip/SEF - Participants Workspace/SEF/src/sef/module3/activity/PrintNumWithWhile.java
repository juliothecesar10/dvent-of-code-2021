/**
 * 
 */
package sef.module3.activity;

/**
 * @author 
 *
 */
public class PrintNumWithWhile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		// Print all even (par) numbers less than 100
		int i = 0;
		while(i<100){
			System.out.println(i);
			i=i+2;			
		}
		
		// Activity 7 
		// write code to Print all odd numbers less than 100
		i = 1;
		while(i<100){
			System.out.println(i);
			i=i+2;			
		}
	}

}
