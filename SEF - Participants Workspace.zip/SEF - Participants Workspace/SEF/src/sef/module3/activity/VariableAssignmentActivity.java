/**
 * 
 */
package sef.module3.activity;

/**
 * @author 
 *
 */
public class VariableAssignmentActivity {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// 1- Declare a variable of type int and assign it default value.
		int variavel_A = 10;
		// 2- Update the value
		variavel_A = 20 + 1;
		// 3- Print updated value to the console
		System.out.printf("Valor : %d\n", variavel_A);

	}

}
