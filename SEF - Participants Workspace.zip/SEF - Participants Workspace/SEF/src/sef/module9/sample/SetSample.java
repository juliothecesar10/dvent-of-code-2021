package sef.module9.sample;
//Needs to be completed
import java.util.*;

public class SetSample {
	public static void main(String[] args) {
		//1 - Create a new HashSet and name it monthSet
		 HashSet<String> monthSet = new HashSet<String>();
		 monthSet.add("January");
		 monthSet.add("January");
		 monthSet.add("February");
		 monthSet.add("March");
		 monthSet.add("April");
		 monthSet.add("May");
		 monthSet.add("May");
		 
		//2 - Add duplicate month names in it. For eg. January can be entered twice
		//duplicates will return false
		//System.out.println(monthSet.add("January"));

		System.out.println("Output : ");
		//3 - Iterate through the HashSet and print all the months.
	    Iterator<String> it = monthSet.iterator();
	    while(it.hasNext()){
	        System.out.println(it.next());
		//You'd notice that duplicate names are not printed. 
	    }
	}
}
