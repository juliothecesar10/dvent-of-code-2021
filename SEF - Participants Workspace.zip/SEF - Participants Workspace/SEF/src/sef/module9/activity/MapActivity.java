package sef.module9.activity;
//Needs to be completed

import java.util.Map;


public class MapActivity {

		public static void main(String[] args) {
			//1 - Type code to create a HashMap of key value pair
			//where key is id of type String and value is a name
			
		
			
			//2 - Call print method to print the map passed as its parameter.
		
		}
		
		void print(Map map)
		{
			//3 - Type code to print this map
		
		}
	}
