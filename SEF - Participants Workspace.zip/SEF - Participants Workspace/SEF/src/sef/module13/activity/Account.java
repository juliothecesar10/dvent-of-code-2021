package sef.module13.activity;
// Complete Code
public interface Account {
	public String getId();
	public String getFirstName();
	public String getLastName();
	public String getEmail();
	public Float getBalance();
}
