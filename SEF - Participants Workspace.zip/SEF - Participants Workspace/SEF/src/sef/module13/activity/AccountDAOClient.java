package sef.module13.activity;
//Needs to be completed

public class AccountDAOClient {
	
	public static void main(String[] args) {
	AccountDAO obj = new AccountDAOImpl();
	
	try {
		
		//Test1 - Type code to test findAccount("1")
	
		
		//Test2 - Type code to test findAccount("J","D"). How many records do you get?
	
		
		//Test3 - Type code to test insertAccount("6","Sasha","Kohli","sasha.kohli@gmail.com",90000)
		
		
		//Test4 - Type code to test deposit("1",2000)
		
		
		//Test5 - Type code to test deposit("2",3000)
		
		
		//Test6 - Type code to test deleteAccount("6")
		
		
	} 
	
	
	}
}