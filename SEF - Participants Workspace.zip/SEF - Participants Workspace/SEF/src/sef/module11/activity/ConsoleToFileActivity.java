package sef.module11.activity;
//Needs to be completed
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class ConsoleToFileActivity {

	public static void main(String[] args) {
		
		//1 - Create variables to store name, age and phone number
		
		
		//2 - Create an object of Scanner class which can read from keyboard 
		
		
		//3 - Print messages to read name, age and phone number and accept all 3 
		
		
		//4 - Create an object of FileOutputStream
		
		try {
			//5 - Initialize FileOutputStream object which is associated with 
			// .\\src\\sef\\module11\\activity\\temp4.txt and also appends everytime it's opened for writing
		
	
			//6 - Write the name, age and phone no to this file.
			//Make sure that this data is delimited(separated) by a colon (:)
			//and each record is written on a new line
	
			
			//7 - Close FileOutputStream object
	
		} catch () {
			e.printStackTrace();
		} catch () {
			e.printStackTrace();
		}
		
System.out.println("Data is written on the file. Thank you.");
	}
}
