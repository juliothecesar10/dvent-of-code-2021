package sef.module6.sample;

public interface Moveable {
	
	public void move();

}
