package sef.module6.sample;

// Bird class implements Moveable interface
public class Bird implements Moveable {
	
	// implements move() method from the Moveable interface
	public void move(){
		System.out.println("Birds can fly");
	}
	
}
