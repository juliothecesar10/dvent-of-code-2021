package sef.module6.sample;

public class InterfaceSample {

	
	public static void main(String[] args) {
		
		Lion l = new Lion();
		Bird b = new Bird();
		
		l.move();
		b.move();
		

	}

}
