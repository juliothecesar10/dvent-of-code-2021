package sef.module6.activity;

/* Person_I class is the superclass 
 * Attributes : name, age
 */
public class Person_I {

	//Attributes
	private String name;
	private int age;
	
	//Behavior - write default constructor. Print 'I'm Person_I constructor'
	
	
	//Behavior - write parameterized constructor
	
	
	// write getter for String name
	
	
	// write setter for String name
	

	// write getter for int age
	

	// write setter for int age
	
}

