package sef.module7.sample;

public class StrategyImplOne implements Strategy {

	public void execute() {
		
		System.out.println("Pincer movement!");
	}

}
