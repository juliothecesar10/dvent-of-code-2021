package sef.module7.sample;

public class StrategyImplTwo implements Strategy {

	public void execute() {
		
		System.out.println("Divide and conquer!");

	}

}
