package sef.module2.sample;

public class DriverShirt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shirt myShirt = new Shirt();
		myShirt.Display();
//		myShirt.Display();
//		System.out.println(myShirt.description);
	}

}
