/**
 * 
 */
package sef.module2.sample;

/**
 * @author j.vieira.ferreira
 *
 */
public class SampleClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println("Esta � a minha classe!");
	}

}    
