package sef.module10.sample;
//Needs to be completed
public class ThreadPriorityClient {

		  public static void main(String args[]){ 
			  
		  //1 - Create an object of ThreadPriority 
		  
		  //2 - Set a priority (MIN_PRIORITY) for this thread.
		  
		  //3 - Start this thread
		  
		  
		  //1 - Create an object of ThreadPriority2
		  
		  //2 - Set a priority (MAX_PRIORITY) for this thread.
		  
		  //3 - Start this thread
		  
		  }
		
}
