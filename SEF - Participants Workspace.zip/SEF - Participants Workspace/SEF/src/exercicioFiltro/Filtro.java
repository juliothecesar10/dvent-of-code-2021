package exercicioFiltro;

public interface Filtro {
	boolean filtra(Disciplina d);
}
